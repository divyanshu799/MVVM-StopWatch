//
//  StopWatchViewModel.swift
//  MVVMTask
//
//  Created by Apple User on 21/04/22.
//

import Foundation

//MARK: - Protocol
protocol StopwatchViewModelDelegate: NSObjectProtocol{
    func updateTimerLabel(sec:String)
}

class StopWatchViewModel: NSObject {
    
    weak var delegate: StopwatchViewModelDelegate?
    var seconds = 0
    var timer = Timer()
    var isTimerRunning = false
    var resumeTapped = false
    
    func runTimer() {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: (#selector(updateTimer)), userInfo: nil, repeats: true)
        isTimerRunning = true
    }
    @objc func updateTimer() {
        seconds += 1
        delegate?.updateTimerLabel(sec: seconds.timeString())
             }
    func updateValues(value : Int){
        switch(value){
        case 1:   runTimer()
        case 2:   timer.invalidate()
                  resumeTapped = true
        case 3:   runTimer()
                  resumeTapped = false
        case 4:    timer.invalidate()
                    seconds = 0
                   isTimerRunning = false
            
        default:
            return
        }
     
    }

}
