//
//  ResumeViewController.swift
//  MVVMTask
//
//  Created by Apple User on 21/04/22.
//

import UIKit

class ResumeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    



}
