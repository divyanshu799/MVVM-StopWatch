//
//  StopViewController.swift
//  MVVMTask
//
//  Created by Apple User on 21/04/22.
//

import UIKit

class StopViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    


}
