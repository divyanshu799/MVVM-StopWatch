//
//  ViewController.swift
//  MVVMTask
//
//  Created by Apple User on 21/04/22.
//

import UIKit

class StopWatchVC: UIViewController {

    //MARK: - Outlets and Properties
    
    @IBOutlet weak var pauseBtn: UIButton!
    @IBOutlet weak var stopBtn: UIButton!
    @IBOutlet weak var startBtn: UIButton!
    @IBOutlet weak var timeLbl: UILabel!
    @IBOutlet weak var alertLbl: UILabel!
    
    private var vmObj: StopWatchViewModel!
    var flag = false
    
    //MARK: - Lifecycle Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pauseBtn.isEnabled = false
        self.vmObj = StopWatchViewModel()
        vmObj.delegate = self
    }
    
    //MARK: - Actions
    
    @IBAction func startTimer(_ sender: Any) {
        if !flag {
            vmObj.updateValues(value: 1)
            pauseBtn.isEnabled = true
            self.startBtn.isEnabled = false
            alertLbl.text = "RUN!!"
            self.stopBtn.setTitle("Reset", for: .normal)
             }
    }
    
    @IBAction func pauseTimer(_ sender: Any) {
  
             if !flag {
                 vmObj.updateValues(value: 2)
                 alertLbl.text = "DON'T STOP NOW!!"
                 self.pauseBtn.setTitle("Resume", for: .normal)
                 flag = true
             } else {
                 vmObj.updateValues(value: 3)
                 alertLbl.text = "KEEP RUNNING!!"
                 self.pauseBtn.setTitle("Pause", for: .normal)
             }
        }
    
    @IBAction func stopTimer(_ sender: Any) {
        vmObj.updateValues(value: 4)
        alertLbl.text = ""
        timeLbl.text = vmObj.seconds.timeString()
        self.stopBtn.setTitle("Stop", for: .normal)
        self.startBtn.isEnabled = true
        self.pauseBtn.isEnabled = false
    }
    
    
}
//MARK: - Extensions
extension StopWatchVC :StopwatchViewModelDelegate{
    
    func updateTimerLabel(sec: String) {
        timeLbl.text = sec
    }
}
